package com.iftah.layouting;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

public class MenuActivity extends AppCompatActivity {

    // 1 Kenalan -buat variabel
    Button btnLinear, btnRelative, btnFrame, btncontraint, btnScroll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

     // 2 sambungkan inisialisasi variabel sesuai dengan id nya
     btnLinear = findViewById(R.id.btnLinear);
     btnRelative = findViewById(R.id.btnRelative);
     btnFrame =  findViewById(R.id.btnFrame);
     btncontraint = findViewById(R.id.btnConstraint);
     btnScroll = findViewById(R.id.btnscroll);

    //3  ngapain - event handing
        btnLinear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             //   Toast.makeText(MenuActivity.this, "Ini Toast", Toast.LENGTH_SHORT).show();
                Intent pindah = new Intent(MenuActivity.this,MainActivity.class);
                startActivity(pindah);
            }
        });
        btnRelative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //komponesn variabel-> new komponen tis
                //content -> namaactivity
                AlertDialog.Builder pesan =  new AlertDialog.Builder(MenuActivity.this);
                pesan.setTitle("Alert  Dialog");
                pesan.setMessage("Ini Alert Dialog");
                pesan.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MenuActivity.this, "Anda milih Ok", Toast.LENGTH_SHORT).show();
                        Intent pindah = new Intent(MenuActivity.this,RelativeActivity.class);
                        startActivity(pindah);
                    }
                });
                pesan.setNegativeButton("NO",null);
                pesan.show();
            }
        });
        btnFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah = new Intent(MenuActivity.this,FrameActivity.class);
                startActivity(pindah);
            }
        });
        btncontraint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah = new Intent(MenuActivity.this,constraintActivity.class);
                startActivity(pindah);
            }
        });
        btnScroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah = new Intent(MenuActivity.this, ScroolActivity.class);
                startActivity(pindah);
            }
        });
    }
}
